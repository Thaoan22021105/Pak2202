#!/bin/sh
QBMSDIR=$PREFIX/share/quickbms
tx=$HOME/thepakv4
down=/storage/emulated/0/Download
dpak=/storage/emulated/0/Download/pak
opak=/storage/emulated/0/Download/output